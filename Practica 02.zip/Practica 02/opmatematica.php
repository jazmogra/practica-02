<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Numero1 = $_POST['numero1'];
    $Numero2 = $_POST['numero2'];

    $suma = $Numero1 + $Numero2;
    $resta = $Numero1 - $Numero2;
    $multiplicacion = $Numero1 * $Numero2;

    if ($Numero2 != 0) {
        $division = $Numero1 / $Numero2;
    } else {
        $division = "Error, División por cero";
    }

    echo "Suma: $suma<br>";
    echo "Resta: $resta<br>";
    echo "Multiplicación: $multiplicacion<br>";
    echo "División: $division<br>";
    /*
    Recordemos: que el echo no devuelve nada,
    es decir recibe múltiples parámetros
    */
}
?>
