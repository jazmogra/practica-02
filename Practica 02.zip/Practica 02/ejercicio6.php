<?php
    $paginas = [
        ['nombre' => 'Google', 'url' => 'https://www.google.com'],
        ['nombre' => 'Facebook', 'url' => 'https://www.facebook.com'],
        ['nombre' => 'Twitter', 'url' => 'https://www.twitter.com']
    ];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Páginas Web</title>
</head>
<body>
    <h1>Menú de Páginas Web</h1>
    <ul>
        <?php
        foreach ($paginas as $pagina) {
            echo "<li><a href='{$pagina['url']}' target='_blank'>{$pagina['nombre']}</a></li>";
        }
        ?>
    </ul>
</body>
</html>
