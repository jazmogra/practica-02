<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $frase = $_POST['frase'];
    $letra = $_POST['letra'];

    $contador = substr_count($frase, $letra);

    echo "La letra '$letra' aparece $contador veces en la frase '$frase'.";
}
?>
