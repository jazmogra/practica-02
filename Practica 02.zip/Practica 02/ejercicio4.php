<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero = $_POST['numero'];
    $aleatorio = rand(1, 10); /*Rand: Funcion que genera aleatoriamente un numero entero*/

    if ($numero == $aleatorio) {
        echo "¡Genial! Has adivinado el número: $aleatorio";
    } else {
        echo "Fallaste, el número era: $aleatorio. Inténtalo de nuevo.";
    }
}
?>
